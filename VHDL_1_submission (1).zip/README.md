# VHDL_1 과제 - Problems 1-5

작성자: 우종민

강의자료 **VHDL_1.pdf 22쪽**의 다섯 문제를 구현했습니다.

| 문제 | 내용 | VHDL 소스 | 바로 실행할 Logisim 회로 |
| --- | --- | --- | --- |
| 1 | 4입력 AND 및 OR | `q1_logic4.vhd` | `Q1_logic4` |
| 2 | 8:1 멀티플렉서 | `q2_mux8.vhd` | `Q2_mux8` |
| 3 | 소문자 a, b, c, d, f, g 표시 | `q3_letters7seg.vhd` | `Q3_letters7seg` |
| 4 | 25인 과반수 투표기 | `q4_vote25.vhd` | `Q4_vote25` |
| 5 | 13비트 1 개수와 7세그먼트 표시 | `q5_popcount13_7seg.vhd` | `Q5_popcount13_7seg` |

프로젝트는 `VHDL_1.circ`, 보고서는 `VHDL_1_Report.pdf`입니다.

## Logisim 실행

1. Logisim-evolution에서 `VHDL_1.circ`를 엽니다.
2. 왼쪽 목록에서 `Q1_logic4`~`Q5_popcount13_7seg` 중 원하는 회로를 두 번 클릭합니다.
3. Poke Tool로 입력을 변경합니다. 다중 비트 입력 핀은 값을 직접 설정할 수 있습니다.
4. 문제 3과 문제 5에서는 `en=1`로 켜고, `en=0`으로 전체 소등합니다.

`Q1`~`Q5`는 Logisim 기본 부품으로 구성한 회로입니다. 별도의 VHDL 시뮬레이터 없이 실행할 수 있습니다.

`HDL_Q1`~`HDL_Q5`에는 해당 VHDL 엔티티가 직접 배치되어 있습니다. 이 다섯 회로를 Logisim 안에서 시뮬레이션하려면 Questa/ModelSim 연결이 필요합니다. VHDL 소스의 실행 검증은 GHDL로, 기본 회로 검증은 Logisim-evolution으로 각각 수행했습니다. 실제 검증 결과는 `validation_results.txt`에 있습니다.

## 입력과 표시 규칙

- 문제 1: `out1 = a AND b AND c AND d`, `out2 = a OR b OR c OR d`.
- 문제 2: `sel=000,001,...,111` 순서로 `a,b,...,h`를 선택합니다.
- 문제 4: `vt(24 downto 0)`의 25개 비트가 각 투표자입니다. 찬성(1)이 13개 이상이면 `result=1`입니다.
- 모든 표시 버스는 `display(7 downto 0) = a b c d e f g dp` 순서입니다. 1은 점등이며 `dp=0`입니다.
- 문제 3의 글꼴은 소문자 형태입니다. 7세그먼트의 표현 한계로 `g`는 숫자 9와 같은 모양입니다.

| 문제 3 dat | 문자 | abcdefgdp | 16진수 |
| --- | --- | --- | --- |
| 000 | a | 11111010 | FA |
| 001 | b | 00111110 | 3E |
| 010 | c | 00011010 | 1A |
| 011 | d | 01111010 | 7A |
| 100 | f | 10001110 | 8E |
| 101 | g | 11110110 | F6 |
| 110 / 111 | 소등 | 00000000 | 00 |

문제 5에서 `vt`는 13비트이므로 1의 개수는 0~13입니다. 실제 표시는 `0~9,A,b,C,d`까지 도달합니다. 요구된 변환표에는 14(E), 15(F)도 구현했지만 13비트 입력만으로는 그 개수에 도달하지 않습니다. `en=0`이면 출력은 `00000000`입니다.

문제 4의 경계 예시(입력 핀은 16진수 표시):

| vt | 찬성 수 | result |
| --- | --- | --- |
| 0000FFF | 12 | 0 |
| 0001FFF | 13 | 1 |
| 1FFFFFF | 25 | 1 |

문제 5에서 `vt=03FF`, `en=1`이면 1이 10개이므로 A가 표시됩니다. `vt=1FFF`, `en=1`이면 d가 표시됩니다.

## VHDL 검증 재현

Python 3와 GHDL이 설치된 환경에서 다음을 실행합니다.

```bash
python tests/run_ghdl.py
```

GHDL이 PATH에 없다면 실행 파일을 지정합니다.

```bash
python tests/run_ghdl.py --ghdl /path/to/ghdl
```

VHDL-93으로 다섯 소스와 `tests/tb_vhdl1.vhd`를 컴파일한 뒤, `tests/q1.txt`~`q5.txt`의 기대값과 비교합니다. 테스트 목록은 0과 1로 이루어진 입력을 대상으로 합니다.

| 문제 | 조건 수 | 범위 |
| --- | --- | --- |
| 1 | 16 | 4비트 전체 입력 |
| 2 | 2,048 | 데이터 256개 x 선택 8개 |
| 3 | 16 | dat 8개 x en 2개 |
| 4 | 5,602 | 모든 찬성 수의 연속 비트 및 순환 배치, 고정 시드 난수 |
| 5 | 16,384 | 모든 13비트 패턴 x en 2개 |
| 합계 | 24,066 | 각 도구에서 동일한 조건 검증 |

문제 4는 2^25 입력 전체를 전수 검증한 것은 아닙니다. 문제 1, 2, 3, 5는 명시한 이진 입력 공간 전체를 검증했습니다. Logisim 검증에서는 문제 3과 5의 출력 버스뿐 아니라 실제 표시기의 8개 입력 핀도 비교했습니다.

기대값 파일의 열은 다음과 같습니다. 모든 값은 10진수입니다.

| 파일 | 열 |
| --- | --- |
| tests/q1.txt | a b c d expected_out1 expected_out2 |
| tests/q2.txt | packed_inputs sel expected_data; packed_inputs의 bit 0=a, ..., bit 7=h |
| tests/q3.txt | dat en expected_display |
| tests/q4.txt | vt expected_result |
| tests/q5.txt | vt en expected_display |

## 제출

압축을 풀어 실제 `.vhd` 파일 5개, `.circ` 프로젝트, `.pdf` 보고서가 GitHub 저장소에서 직접 보이도록 업로드합니다. README와 tests 폴더도 함께 올리면 검증 과정을 재현할 수 있습니다. 교수자가 저장소를 열 수 있는지 확인하고, LMS에는 저장소 링크 하나만 제출합니다.

참고: Zhuoheng Li, *Digital Logic Circuit Design*, `VHDL_1.pdf`, 16~22쪽.
