library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;

entity tb_vhdl1 is end tb_vhdl1;

architecture simulation of tb_vhdl1 is
    signal v1 : std_logic_vector(3 downto 0) := (others => '0');
    signal and4, or4 : std_logic;
    signal v2 : std_logic_vector(7 downto 0) := (others => '0');
    signal sel : std_logic_vector(2 downto 0) := (others => '0');
    signal mux_data : std_logic;
    signal dat : std_logic_vector(2 downto 0) := (others => '0');
    signal en3 : std_logic := '0';
    signal display3 : std_logic_vector(7 downto 0);
    signal vt25 : std_logic_vector(24 downto 0) := (others => '0');
    signal vote_result : std_logic;
    signal vt13 : std_logic_vector(12 downto 0) := (others => '0');
    signal en5 : std_logic := '0';
    signal display5 : std_logic_vector(7 downto 0);
begin
    u1: entity work.q1_logic4 port map(v1(3),v1(2),v1(1),v1(0),and4,or4);
    u2: entity work.q2_mux8 port map(v2(0),v2(1),v2(2),v2(3),v2(4),v2(5),v2(6),v2(7),sel,mux_data);
    u3: entity work.q3_letters7seg port map(en3,dat,display3);
    u4: entity work.q4_vote25 port map(vt25,vote_result);
    u5: entity work.q5_popcount13_7seg port map(vt13,en5,display5);

    stimulus: process
        file vectors : text;
        variable line_in : line;
        variable p,q,r,s,t,u : integer;
        variable count : natural;
        function bit_value(value : integer) return std_logic is
        begin
            if value=0 then return '0'; else return '1'; end if;
        end bit_value;
    begin
        file_open(vectors,"q1.txt",read_mode); count:=0;
        while not endfile(vectors) loop
            readline(vectors,line_in);
            read(line_in,p);read(line_in,q);read(line_in,r);read(line_in,s);read(line_in,t);read(line_in,u);
            v1<=bit_value(p)&bit_value(q)&bit_value(r)&bit_value(s);
            wait for 1 ns;
            assert and4=bit_value(t) and or4=bit_value(u) report "Q1 mismatch" severity failure;
            count:=count+1;
        end loop;
        file_close(vectors); report "Q1 PASS: "&integer'image(count)&" cases";

        file_open(vectors,"q2.txt",read_mode); count:=0;
        while not endfile(vectors) loop
            readline(vectors,line_in);read(line_in,p);read(line_in,q);read(line_in,r);
            v2<=std_logic_vector(to_unsigned(p,8));sel<=std_logic_vector(to_unsigned(q,3));
            wait for 1 ns;
            assert mux_data=bit_value(r) report "Q2 mismatch" severity failure;
            count:=count+1;
        end loop;
        file_close(vectors); report "Q2 PASS: "&integer'image(count)&" cases";

        file_open(vectors,"q3.txt",read_mode); count:=0;
        while not endfile(vectors) loop
            readline(vectors,line_in);read(line_in,p);read(line_in,q);read(line_in,r);
            dat<=std_logic_vector(to_unsigned(p,3));en3<=bit_value(q);
            wait for 1 ns;
            assert display3=std_logic_vector(to_unsigned(r,8)) report "Q3 mismatch" severity failure;
            count:=count+1;
        end loop;
        file_close(vectors); report "Q3 PASS: "&integer'image(count)&" cases";

        file_open(vectors,"q4.txt",read_mode); count:=0;
        while not endfile(vectors) loop
            readline(vectors,line_in);read(line_in,p);read(line_in,q);
            vt25<=std_logic_vector(to_unsigned(p,25));wait for 1 ns;
            assert vote_result=bit_value(q) report "Q4 mismatch" severity failure;
            count:=count+1;
        end loop;
        file_close(vectors); report "Q4 PASS: "&integer'image(count)&" cases";

        file_open(vectors,"q5.txt",read_mode); count:=0;
        while not endfile(vectors) loop
            readline(vectors,line_in);read(line_in,p);read(line_in,q);read(line_in,r);
            vt13<=std_logic_vector(to_unsigned(p,13));en5<=bit_value(q);
            wait for 1 ns;
            assert display5=std_logic_vector(to_unsigned(r,8)) report "Q5 mismatch" severity failure;
            count:=count+1;
        end loop;
        file_close(vectors); report "Q5 PASS: "&integer'image(count)&" cases";
        report "ALL FIVE PROBLEMS PASS";
        wait;
    end process;
end simulation;
