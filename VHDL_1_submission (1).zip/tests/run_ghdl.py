"""Reproduce the five VHDL regression tests with GHDL (VHDL-93)."""
import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--ghdl', default=shutil.which('ghdl'), help='GHDL executable path')
args = parser.parse_args()
if not args.ghdl:
    parser.error('GHDL was not found. Add it to PATH or use --ghdl /path/to/ghdl.')

tests = Path(__file__).resolve().parent
sources = sorted(tests.parent.glob('q[1-5]_*.vhd'))
if len(sources) != 5:
    raise SystemExit('Expected the five q1..q5 VHDL files next to the tests folder.')

with tempfile.TemporaryDirectory(prefix='vhdl1-test-') as work:
    common = ['--std=93', '--workdir=' + work]
    commands = [
        [args.ghdl, '-a', *common, *map(str, sources), str(tests / 'tb_vhdl1.vhd')],
        [args.ghdl, '-e', *common, 'tb_vhdl1'],
        [args.ghdl, '-r', *common, 'tb_vhdl1', '--assert-level=error'],
    ]
    for command in commands:
        subprocess.run(command, cwd=tests, check=True)
print('All five VHDL problems passed.')
